package com.example.afrida_biggernumber;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
private Button b1,b2;
private TextView t1,t2,t3;
int r1,r2;
int count=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1 = (Button) findViewById(R.id.button1Id);
        b2 = (Button) findViewById(R.id.button2Id);
        t3=(TextView)findViewById(R.id.txtId3);
    }
    private void giveNewRand(){
        Random rand= new Random();
        r1=rand.nextInt(100);
        while (true) {


            r2 = rand.nextInt(100);
            if (r1 != r2)
                break;
        }
        b1.setText(Integer.toString(r1));
        b2.setText(Integer.toString(r2));
    }

    public void onclick_left(View view) {
if(r1>r2){
    count++;
}else{
    count--;
}
t3.setText("Point:"+count);
        giveNewRand();
    }

    public void onclick_right(View view) {
        if(r2>r1){
            count++;
        }else{
            count--;
        }
        t3.setText("Point:"+count);
        giveNewRand();
    }
}
